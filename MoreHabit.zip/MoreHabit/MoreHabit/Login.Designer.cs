﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 17/11/2025
 * Time: 10:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace MoreHabit
{
	partial class Login
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lblLogin = new System.Windows.Forms.Label();
			this.lblUsuario = new System.Windows.Forms.Label();
			this.lblSenha = new System.Windows.Forms.Label();
			this.lblSemconta = new System.Windows.Forms.Label();
			this.txtUsuario = new System.Windows.Forms.TextBox();
			this.txtSenha = new System.Windows.Forms.TextBox();
			this.lblCrieuma = new System.Windows.Forms.Label();
			this.btnEntrar = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(138, 34);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(883, 417);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 2;
			this.pictureBox1.TabStop = false;
			// 
			// lblLogin
			// 
			this.lblLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblLogin.Font = new System.Drawing.Font("Arial", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLogin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblLogin.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblLogin.Location = new System.Drawing.Point(424, 83);
			this.lblLogin.Name = "lblLogin";
			this.lblLogin.Size = new System.Drawing.Size(342, 56);
			this.lblLogin.TabIndex = 3;
			this.lblLogin.Text = "Login";
			this.lblLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblUsuario
			// 
			this.lblUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblUsuario.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUsuario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblUsuario.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblUsuario.Location = new System.Drawing.Point(186, 164);
			this.lblUsuario.Name = "lblUsuario";
			this.lblUsuario.Size = new System.Drawing.Size(118, 31);
			this.lblUsuario.TabIndex = 4;
			this.lblUsuario.Text = "Usuário:";
			this.lblUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblSenha
			// 
			this.lblSenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblSenha.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblSenha.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblSenha.Location = new System.Drawing.Point(186, 271);
			this.lblSenha.Name = "lblSenha";
			this.lblSenha.Size = new System.Drawing.Size(118, 31);
			this.lblSenha.TabIndex = 5;
			this.lblSenha.Text = "Senha:";
			this.lblSenha.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblSemconta
			// 
			this.lblSemconta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblSemconta.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSemconta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblSemconta.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblSemconta.Location = new System.Drawing.Point(186, 370);
			this.lblSemconta.Name = "lblSemconta";
			this.lblSemconta.Size = new System.Drawing.Size(238, 31);
			this.lblSemconta.TabIndex = 6;
			this.lblSemconta.Text = "Não tem uma conta?";
			this.lblSemconta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtUsuario
			// 
			this.txtUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(217)))));
			this.txtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtUsuario.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtUsuario.Location = new System.Drawing.Point(186, 215);
			this.txtUsuario.Name = "txtUsuario";
			this.txtUsuario.Size = new System.Drawing.Size(791, 33);
			this.txtUsuario.TabIndex = 7;
			// 
			// txtSenha
			// 
			this.txtSenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(217)))));
			this.txtSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtSenha.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtSenha.Location = new System.Drawing.Point(186, 305);
			this.txtSenha.Name = "txtSenha";
			this.txtSenha.PasswordChar = '*';
			this.txtSenha.Size = new System.Drawing.Size(791, 33);
			this.txtSenha.TabIndex = 8;
			// 
			// lblCrieuma
			// 
			this.lblCrieuma.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblCrieuma.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lblCrieuma.Font = new System.Drawing.Font("Arial", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCrieuma.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblCrieuma.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblCrieuma.Location = new System.Drawing.Point(400, 370);
			this.lblCrieuma.Name = "lblCrieuma";
			this.lblCrieuma.Size = new System.Drawing.Size(199, 31);
			this.lblCrieuma.TabIndex = 9;
			this.lblCrieuma.Text = "Crie uma";
			this.lblCrieuma.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCrieuma.Click += new System.EventHandler(this.LblCrieumaClick);
			// 
			// btnEntrar
			// 
			this.btnEntrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.btnEntrar.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEntrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnEntrar.Location = new System.Drawing.Point(827, 364);
			this.btnEntrar.Name = "btnEntrar";
			this.btnEntrar.Size = new System.Drawing.Size(120, 44);
			this.btnEntrar.TabIndex = 10;
			this.btnEntrar.Text = "Entrar";
			this.btnEntrar.UseVisualStyleBackColor = false;
			this.btnEntrar.Click += new System.EventHandler(this.BtnEntrarClick);
			// 
			// Login
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(1142, 488);
			this.Controls.Add(this.btnEntrar);
			this.Controls.Add(this.lblCrieuma);
			this.Controls.Add(this.txtSenha);
			this.Controls.Add(this.txtUsuario);
			this.Controls.Add(this.lblSemconta);
			this.Controls.Add(this.lblSenha);
			this.Controls.Add(this.lblUsuario);
			this.Controls.Add(this.lblLogin);
			this.Controls.Add(this.pictureBox1);
			this.Name = "Login";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "+Habit";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button btnEntrar;
		private System.Windows.Forms.Label lblCrieuma;
		private System.Windows.Forms.TextBox txtSenha;
		private System.Windows.Forms.TextBox txtUsuario;
		private System.Windows.Forms.Label lblSemconta;
		private System.Windows.Forms.Label lblSenha;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label lblLogin;
		private System.Windows.Forms.Label lblUsuario;
	}
}
