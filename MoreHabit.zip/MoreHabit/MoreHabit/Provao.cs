﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 24/11/2025
 * Time: 09:23
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace MoreHabit
{
	/// <summary>
	/// Description of Provao.
	/// </summary>
	public partial class Provao : Form
	{
		public Provao()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		
		int perguntaAtual = 1;
		void BtnVoltarClick(object sender, EventArgs e)
		{
		Inicio telaInicial = new Inicio();
          telaInicial.Show();
          this.Hide();				
		}
		
		void BtnProximoClick(object sender, EventArgs e)
		{
		 perguntaAtual++;

    if (perguntaAtual == 1)
    {
        pnlQuestao1.Visible = true;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 2)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = true;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 3)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = true;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 4)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = true;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 5)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = true;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 6)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = true;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 7)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = true;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 8)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = true;
    }
    else if (perguntaAtual >= 9) 
    {
    	pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = true;
        MessageBox.Show("Essa é a última questão!");
    }
		}
		
		void PnlPaint(object sender, PaintEventArgs e)
		{
			
		}
		
		void BtnAnteriorClick(object sender, EventArgs e)
		{
  perguntaAtual--;

    if (perguntaAtual == 1)
    {
        pnlQuestao1.Visible = true;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 2)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = true;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 3)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = true;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 4)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = true;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 5)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = true;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 6)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = true;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 7)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = true;
        pnlQuestao8.Visible = false;
    }
    else if (perguntaAtual == 8)
    {
        pnlQuestao1.Visible = false;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = true;
    }
    else if (perguntaAtual <= 0) 
    {
    	pnlQuestao1.Visible = true;
        pnlQuestao2.Visible = false;
        pnlQuestao3.Visible = false;
        pnlQuestao4.Visible = false;
        pnlQuestao5.Visible = false;
        pnlQuestao6.Visible = false;
        pnlQuestao7.Visible = false;
        pnlQuestao8.Visible = false;
        MessageBox.Show("Essa é a primeira questão!");
    }
		}
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
	}
}
