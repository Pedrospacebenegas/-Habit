﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 24/11/2025
 * Time: 09:23
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace MoreHabit
{
	partial class Habitos
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Habitos));
			this.btnVoltar = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pnlQuestao1 = new System.Windows.Forms.Panel();
			this.pnlQuestao3 = new System.Windows.Forms.Panel();
			this.btnAlternativaD3 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC3 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB3 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA3 = new System.Windows.Forms.RadioButton();
			this.label1 = new System.Windows.Forms.Label();
			this.btnAlternativaD = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA = new System.Windows.Forms.RadioButton();
			this.lblQuestao1 = new System.Windows.Forms.Label();
			this.pnlQuestao5 = new System.Windows.Forms.Panel();
			this.btnAlternativaD5 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC5 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB5 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA5 = new System.Windows.Forms.RadioButton();
			this.lblQuestao5 = new System.Windows.Forms.Label();
			this.pnlQuestao2 = new System.Windows.Forms.Panel();
			this.btnAlternativaD2 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC2 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB2 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA2 = new System.Windows.Forms.RadioButton();
			this.lblQuestao2 = new System.Windows.Forms.Label();
			this.pnlQuestao4 = new System.Windows.Forms.Panel();
			this.btnAlternativaD4 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC4 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB4 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA4 = new System.Windows.Forms.RadioButton();
			this.lblQuestao4 = new System.Windows.Forms.Label();
			this.btnAnterior = new System.Windows.Forms.Button();
			this.btnProximo = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.pnlQuestao1.SuspendLayout();
			this.pnlQuestao3.SuspendLayout();
			this.pnlQuestao5.SuspendLayout();
			this.pnlQuestao2.SuspendLayout();
			this.pnlQuestao4.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnVoltar
			// 
			this.btnVoltar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.btnVoltar.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnVoltar.Location = new System.Drawing.Point(12, 12);
			this.btnVoltar.Name = "btnVoltar";
			this.btnVoltar.Size = new System.Drawing.Size(120, 44);
			this.btnVoltar.TabIndex = 12;
			this.btnVoltar.Text = "Voltar";
			this.btnVoltar.UseVisualStyleBackColor = false;
			this.btnVoltar.Click += new System.EventHandler(this.BtnVoltarClick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(135, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(738, 335);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 15;
			this.pictureBox1.TabStop = false;
			// 
			// pnlQuestao1
			// 
			this.pnlQuestao1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao1.Controls.Add(this.btnAlternativaD);
			this.pnlQuestao1.Controls.Add(this.btnAlternativaC);
			this.pnlQuestao1.Controls.Add(this.btnAlternativaB);
			this.pnlQuestao1.Controls.Add(this.btnAlternativaA);
			this.pnlQuestao1.Controls.Add(this.lblQuestao1);
			this.pnlQuestao1.Location = new System.Drawing.Point(162, 44);
			this.pnlQuestao1.Name = "pnlQuestao1";
			this.pnlQuestao1.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao1.TabIndex = 18;
			// 
			// pnlQuestao3
			// 
			this.pnlQuestao3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao3.Controls.Add(this.btnAlternativaD3);
			this.pnlQuestao3.Controls.Add(this.btnAlternativaC3);
			this.pnlQuestao3.Controls.Add(this.btnAlternativaB3);
			this.pnlQuestao3.Controls.Add(this.btnAlternativaA3);
			this.pnlQuestao3.Controls.Add(this.label1);
			this.pnlQuestao3.Location = new System.Drawing.Point(161, 41);
			this.pnlQuestao3.Name = "pnlQuestao3";
			this.pnlQuestao3.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao3.TabIndex = 21;
			this.pnlQuestao3.Visible = false;
			// 
			// btnAlternativaD3
			// 
			this.btnAlternativaD3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD3.Location = new System.Drawing.Point(39, 206);
			this.btnAlternativaD3.Name = "btnAlternativaD3";
			this.btnAlternativaD3.Size = new System.Drawing.Size(615, 36);
			this.btnAlternativaD3.TabIndex = 5;
			this.btnAlternativaD3.TabStop = true;
			this.btnAlternativaD3.Text = "D) Conseguir todos os macro e micro nutrientes.";
			this.btnAlternativaD3.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC3
			// 
			this.btnAlternativaC3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC3.Location = new System.Drawing.Point(39, 156);
			this.btnAlternativaC3.Name = "btnAlternativaC3";
			this.btnAlternativaC3.Size = new System.Drawing.Size(314, 44);
			this.btnAlternativaC3.TabIndex = 4;
			this.btnAlternativaC3.TabStop = true;
			this.btnAlternativaC3.Text = "C) Consumo de proteína.";
			this.btnAlternativaC3.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB3
			// 
			this.btnAlternativaB3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB3.Location = new System.Drawing.Point(39, 113);
			this.btnAlternativaB3.Name = "btnAlternativaB3";
			this.btnAlternativaB3.Size = new System.Drawing.Size(386, 37);
			this.btnAlternativaB3.TabIndex = 3;
			this.btnAlternativaB3.TabStop = true;
			this.btnAlternativaB3.Text = "B) Quantidade de alimentos.";
			this.btnAlternativaB3.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA3
			// 
			this.btnAlternativaA3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA3.Location = new System.Drawing.Point(39, 67);
			this.btnAlternativaA3.Name = "btnAlternativaA3";
			this.btnAlternativaA3.Size = new System.Drawing.Size(421, 27);
			this.btnAlternativaA3.TabIndex = 2;
			this.btnAlternativaA3.TabStop = true;
			this.btnAlternativaA3.Text = "A) Quantidade de calorias.";
			this.btnAlternativaA3.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.label1.Location = new System.Drawing.Point(17, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(667, 43);
			this.label1.TabIndex = 1;
			this.label1.Text = "3. Qual é o fator mais importante quando se alimenta?";
			// 
			// btnAlternativaD
			// 
			this.btnAlternativaD.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD.Location = new System.Drawing.Point(39, 206);
			this.btnAlternativaD.Name = "btnAlternativaD";
			this.btnAlternativaD.Size = new System.Drawing.Size(314, 36);
			this.btnAlternativaD.TabIndex = 5;
			this.btnAlternativaD.TabStop = true;
			this.btnAlternativaD.Text = "D) 30 minutos.";
			this.btnAlternativaD.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC
			// 
			this.btnAlternativaC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC.Location = new System.Drawing.Point(39, 156);
			this.btnAlternativaC.Name = "btnAlternativaC";
			this.btnAlternativaC.Size = new System.Drawing.Size(314, 44);
			this.btnAlternativaC.TabIndex = 4;
			this.btnAlternativaC.TabStop = true;
			this.btnAlternativaC.Text = "C) 2 Horas.";
			this.btnAlternativaC.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB
			// 
			this.btnAlternativaB.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB.Location = new System.Drawing.Point(39, 113);
			this.btnAlternativaB.Name = "btnAlternativaB";
			this.btnAlternativaB.Size = new System.Drawing.Size(386, 37);
			this.btnAlternativaB.TabIndex = 3;
			this.btnAlternativaB.TabStop = true;
			this.btnAlternativaB.Text = "B) 1 Horas.";
			this.btnAlternativaB.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA
			// 
			this.btnAlternativaA.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA.Location = new System.Drawing.Point(39, 67);
			this.btnAlternativaA.Name = "btnAlternativaA";
			this.btnAlternativaA.Size = new System.Drawing.Size(421, 27);
			this.btnAlternativaA.TabIndex = 2;
			this.btnAlternativaA.TabStop = true;
			this.btnAlternativaA.Text = "A) 0 Horas.";
			this.btnAlternativaA.UseVisualStyleBackColor = true;
			// 
			// lblQuestao1
			// 
			this.lblQuestao1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao1.Location = new System.Drawing.Point(17, 15);
			this.lblQuestao1.Name = "lblQuestao1";
			this.lblQuestao1.Size = new System.Drawing.Size(667, 43);
			this.lblQuestao1.TabIndex = 1;
			this.lblQuestao1.Text = "1. Quantas horas de estudo fora da escola se deve fazer em temporada de prova?";
			this.lblQuestao1.Click += new System.EventHandler(this.LblQuestão1Click);
			// 
			// pnlQuestao5
			// 
			this.pnlQuestao5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao5.Controls.Add(this.btnAlternativaD5);
			this.pnlQuestao5.Controls.Add(this.btnAlternativaC5);
			this.pnlQuestao5.Controls.Add(this.btnAlternativaB5);
			this.pnlQuestao5.Controls.Add(this.btnAlternativaA5);
			this.pnlQuestao5.Controls.Add(this.lblQuestao5);
			this.pnlQuestao5.Location = new System.Drawing.Point(168, 35);
			this.pnlQuestao5.Name = "pnlQuestao5";
			this.pnlQuestao5.Size = new System.Drawing.Size(684, 265);
			this.pnlQuestao5.TabIndex = 21;
			this.pnlQuestao5.Visible = false;
			// 
			// btnAlternativaD5
			// 
			this.btnAlternativaD5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD5.Location = new System.Drawing.Point(39, 206);
			this.btnAlternativaD5.Name = "btnAlternativaD5";
			this.btnAlternativaD5.Size = new System.Drawing.Size(615, 36);
			this.btnAlternativaD5.TabIndex = 5;
			this.btnAlternativaD5.TabStop = true;
			this.btnAlternativaD5.Text = "D) Todos acima.";
			this.btnAlternativaD5.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC5
			// 
			this.btnAlternativaC5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC5.Location = new System.Drawing.Point(39, 156);
			this.btnAlternativaC5.Name = "btnAlternativaC5";
			this.btnAlternativaC5.Size = new System.Drawing.Size(314, 44);
			this.btnAlternativaC5.TabIndex = 4;
			this.btnAlternativaC5.TabStop = true;
			this.btnAlternativaC5.Text = "C) Dar tempo para os hobbies.";
			this.btnAlternativaC5.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB5
			// 
			this.btnAlternativaB5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB5.Location = new System.Drawing.Point(39, 113);
			this.btnAlternativaB5.Name = "btnAlternativaB5";
			this.btnAlternativaB5.Size = new System.Drawing.Size(386, 37);
			this.btnAlternativaB5.TabIndex = 3;
			this.btnAlternativaB5.TabStop = true;
			this.btnAlternativaB5.Text = "B) Se recompensar pelos estudos.";
			this.btnAlternativaB5.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA5
			// 
			this.btnAlternativaA5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA5.Location = new System.Drawing.Point(39, 67);
			this.btnAlternativaA5.Name = "btnAlternativaA5";
			this.btnAlternativaA5.Size = new System.Drawing.Size(421, 27);
			this.btnAlternativaA5.TabIndex = 2;
			this.btnAlternativaA5.TabStop = true;
			this.btnAlternativaA5.Text = "A) Não se esforçar demais de uma vez.";
			this.btnAlternativaA5.UseVisualStyleBackColor = true;
			// 
			// lblQuestao5
			// 
			this.lblQuestao5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao5.Location = new System.Drawing.Point(17, 15);
			this.lblQuestao5.Name = "lblQuestao5";
			this.lblQuestao5.Size = new System.Drawing.Size(667, 43);
			this.lblQuestao5.TabIndex = 1;
			this.lblQuestao5.Text = "5. Para manter uma rotina de estudos regulares o fator mais importante é:";
			// 
			// pnlQuestao2
			// 
			this.pnlQuestao2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao2.Controls.Add(this.btnAlternativaD2);
			this.pnlQuestao2.Controls.Add(this.btnAlternativaC2);
			this.pnlQuestao2.Controls.Add(this.btnAlternativaB2);
			this.pnlQuestao2.Controls.Add(this.btnAlternativaA2);
			this.pnlQuestao2.Controls.Add(this.lblQuestao2);
			this.pnlQuestao2.Location = new System.Drawing.Point(159, 38);
			this.pnlQuestao2.Name = "pnlQuestao2";
			this.pnlQuestao2.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao2.TabIndex = 19;
			this.pnlQuestao2.Visible = false;
			// 
			// btnAlternativaD2
			// 
			this.btnAlternativaD2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD2.Location = new System.Drawing.Point(39, 206);
			this.btnAlternativaD2.Name = "btnAlternativaD2";
			this.btnAlternativaD2.Size = new System.Drawing.Size(314, 36);
			this.btnAlternativaD2.TabIndex = 5;
			this.btnAlternativaD2.TabStop = true;
			this.btnAlternativaD2.Text = "D) 9 Horas.";
			this.btnAlternativaD2.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC2
			// 
			this.btnAlternativaC2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC2.Location = new System.Drawing.Point(39, 156);
			this.btnAlternativaC2.Name = "btnAlternativaC2";
			this.btnAlternativaC2.Size = new System.Drawing.Size(314, 44);
			this.btnAlternativaC2.TabIndex = 4;
			this.btnAlternativaC2.TabStop = true;
			this.btnAlternativaC2.Text = "C) 8 Horas.";
			this.btnAlternativaC2.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB2
			// 
			this.btnAlternativaB2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB2.Location = new System.Drawing.Point(39, 113);
			this.btnAlternativaB2.Name = "btnAlternativaB2";
			this.btnAlternativaB2.Size = new System.Drawing.Size(386, 37);
			this.btnAlternativaB2.TabIndex = 3;
			this.btnAlternativaB2.TabStop = true;
			this.btnAlternativaB2.Text = "B) 7 Horas.";
			this.btnAlternativaB2.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA2
			// 
			this.btnAlternativaA2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA2.Location = new System.Drawing.Point(39, 67);
			this.btnAlternativaA2.Name = "btnAlternativaA2";
			this.btnAlternativaA2.Size = new System.Drawing.Size(421, 27);
			this.btnAlternativaA2.TabIndex = 2;
			this.btnAlternativaA2.TabStop = true;
			this.btnAlternativaA2.Text = "A) 6 Horas.";
			this.btnAlternativaA2.UseVisualStyleBackColor = true;
			// 
			// lblQuestao2
			// 
			this.lblQuestao2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao2.Location = new System.Drawing.Point(17, 15);
			this.lblQuestao2.Name = "lblQuestao2";
			this.lblQuestao2.Size = new System.Drawing.Size(667, 43);
			this.lblQuestao2.TabIndex = 1;
			this.lblQuestao2.Text = "2. Quantas horas de sono é recomendada para um aluno?";
			this.lblQuestao2.Click += new System.EventHandler(this.Label1Click);
			// 
			// pnlQuestao4
			// 
			this.pnlQuestao4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao4.Controls.Add(this.btnAlternativaD4);
			this.pnlQuestao4.Controls.Add(this.btnAlternativaC4);
			this.pnlQuestao4.Controls.Add(this.btnAlternativaB4);
			this.pnlQuestao4.Controls.Add(this.btnAlternativaA4);
			this.pnlQuestao4.Controls.Add(this.lblQuestao4);
			this.pnlQuestao4.Location = new System.Drawing.Point(165, 38);
			this.pnlQuestao4.Name = "pnlQuestao4";
			this.pnlQuestao4.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao4.TabIndex = 20;
			this.pnlQuestao4.Visible = false;
			// 
			// btnAlternativaD4
			// 
			this.btnAlternativaD4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD4.Location = new System.Drawing.Point(39, 206);
			this.btnAlternativaD4.Name = "btnAlternativaD4";
			this.btnAlternativaD4.Size = new System.Drawing.Size(615, 36);
			this.btnAlternativaD4.TabIndex = 5;
			this.btnAlternativaD4.TabStop = true;
			this.btnAlternativaD4.Text = "D) 6 Horas.";
			this.btnAlternativaD4.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC4
			// 
			this.btnAlternativaC4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC4.Location = new System.Drawing.Point(39, 156);
			this.btnAlternativaC4.Name = "btnAlternativaC4";
			this.btnAlternativaC4.Size = new System.Drawing.Size(314, 44);
			this.btnAlternativaC4.TabIndex = 4;
			this.btnAlternativaC4.TabStop = true;
			this.btnAlternativaC4.Text = "C) 5 Horas.";
			this.btnAlternativaC4.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB4
			// 
			this.btnAlternativaB4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB4.Location = new System.Drawing.Point(39, 113);
			this.btnAlternativaB4.Name = "btnAlternativaB4";
			this.btnAlternativaB4.Size = new System.Drawing.Size(386, 37);
			this.btnAlternativaB4.TabIndex = 3;
			this.btnAlternativaB4.TabStop = true;
			this.btnAlternativaB4.Text = "B) 4 Horas.";
			this.btnAlternativaB4.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA4
			// 
			this.btnAlternativaA4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA4.Location = new System.Drawing.Point(39, 67);
			this.btnAlternativaA4.Name = "btnAlternativaA4";
			this.btnAlternativaA4.Size = new System.Drawing.Size(421, 27);
			this.btnAlternativaA4.TabIndex = 2;
			this.btnAlternativaA4.TabStop = true;
			this.btnAlternativaA4.Text = "A) 3 Horas.";
			this.btnAlternativaA4.UseVisualStyleBackColor = true;
			// 
			// lblQuestao4
			// 
			this.lblQuestao4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao4.Location = new System.Drawing.Point(17, 15);
			this.lblQuestao4.Name = "lblQuestao4";
			this.lblQuestao4.Size = new System.Drawing.Size(667, 43);
			this.lblQuestao4.TabIndex = 1;
			this.lblQuestao4.Text = "4. Quanto tempo se deve dedicar ao seus hobbies por semana?";
			// 
			// btnAnterior
			// 
			this.btnAnterior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.btnAnterior.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAnterior.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAnterior.Location = new System.Drawing.Point(135, 353);
			this.btnAnterior.Name = "btnAnterior";
			this.btnAnterior.Size = new System.Drawing.Size(120, 44);
			this.btnAnterior.TabIndex = 19;
			this.btnAnterior.Text = "Anterior";
			this.btnAnterior.UseVisualStyleBackColor = false;
			this.btnAnterior.Click += new System.EventHandler(this.BtnAnteriorClick);
			// 
			// btnProximo
			// 
			this.btnProximo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.btnProximo.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnProximo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnProximo.Location = new System.Drawing.Point(753, 353);
			this.btnProximo.Name = "btnProximo";
			this.btnProximo.Size = new System.Drawing.Size(120, 44);
			this.btnProximo.TabIndex = 20;
			this.btnProximo.Text = "Próximo";
			this.btnProximo.UseVisualStyleBackColor = false;
			this.btnProximo.Click += new System.EventHandler(this.BtnProximoClick);
			// 
			// Habitos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(993, 425);
			this.Controls.Add(this.pnlQuestao3);
			this.Controls.Add(this.pnlQuestao4);
			this.Controls.Add(this.pnlQuestao2);
			this.Controls.Add(this.pnlQuestao5);
			this.Controls.Add(this.btnProximo);
			this.Controls.Add(this.btnAnterior);
			this.Controls.Add(this.pnlQuestao1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.btnVoltar);
			this.Name = "Habitos";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "+Habit";
			this.Load += new System.EventHandler(this.HabitosLoad);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.pnlQuestao1.ResumeLayout(false);
			this.pnlQuestao3.ResumeLayout(false);
			this.pnlQuestao5.ResumeLayout(false);
			this.pnlQuestao2.ResumeLayout(false);
			this.pnlQuestao4.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RadioButton btnAlternativaA3;
		private System.Windows.Forms.RadioButton btnAlternativaB3;
		private System.Windows.Forms.RadioButton btnAlternativaC3;
		private System.Windows.Forms.RadioButton btnAlternativaD3;
		private System.Windows.Forms.Panel pnlQuestao3;
		private System.Windows.Forms.Label lblQuestao5;
		private System.Windows.Forms.RadioButton btnAlternativaA5;
		private System.Windows.Forms.RadioButton btnAlternativaB5;
		private System.Windows.Forms.RadioButton btnAlternativaC5;
		private System.Windows.Forms.RadioButton btnAlternativaD5;
		private System.Windows.Forms.Panel pnlQuestao5;
		private System.Windows.Forms.Panel pnlQuestao2;
		private System.Windows.Forms.Label lblQuestao4;
		private System.Windows.Forms.RadioButton btnAlternativaA4;
		private System.Windows.Forms.RadioButton btnAlternativaB4;
		private System.Windows.Forms.RadioButton btnAlternativaC4;
		private System.Windows.Forms.RadioButton btnAlternativaD4;
		private System.Windows.Forms.Panel pnlQuestao4;
		private System.Windows.Forms.Label lblQuestao2;
		private System.Windows.Forms.RadioButton btnAlternativaA2;
		private System.Windows.Forms.RadioButton btnAlternativaB2;
		private System.Windows.Forms.RadioButton btnAlternativaC2;
		private System.Windows.Forms.RadioButton btnAlternativaD2;
		private System.Windows.Forms.Button btnProximo;
		private System.Windows.Forms.Button btnAnterior;
		private System.Windows.Forms.Label lblQuestao1;
		private System.Windows.Forms.RadioButton btnAlternativaA;
		private System.Windows.Forms.RadioButton btnAlternativaB;
		private System.Windows.Forms.RadioButton btnAlternativaC;
		private System.Windows.Forms.RadioButton btnAlternativaD;
		private System.Windows.Forms.Panel pnlQuestao1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btnVoltar;
	}
}
