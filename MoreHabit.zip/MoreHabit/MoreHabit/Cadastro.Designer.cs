﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 17/11/2025
 * Time: 11:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace MoreHabit
{
	partial class Cadastro
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cadastro));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lblCadastro = new System.Windows.Forms.Label();
			this.lblUsuario2 = new System.Windows.Forms.Label();
			this.lblSenha2 = new System.Windows.Forms.Label();
			this.txtUsuario2 = new System.Windows.Forms.TextBox();
			this.txtSenha2 = new System.Windows.Forms.TextBox();
			this.btnCadastrar = new System.Windows.Forms.Button();
			this.lblComconta = new System.Windows.Forms.Label();
			this.lblLogin2 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(131, 27);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(883, 398);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 3;
			this.pictureBox1.TabStop = false;
			// 
			// lblCadastro
			// 
			this.lblCadastro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblCadastro.Font = new System.Drawing.Font("Arial", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCadastro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblCadastro.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblCadastro.Location = new System.Drawing.Point(410, 79);
			this.lblCadastro.Name = "lblCadastro";
			this.lblCadastro.Size = new System.Drawing.Size(342, 56);
			this.lblCadastro.TabIndex = 4;
			this.lblCadastro.Text = "Cadastro";
			this.lblCadastro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblUsuario2
			// 
			this.lblUsuario2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblUsuario2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUsuario2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblUsuario2.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblUsuario2.Location = new System.Drawing.Point(189, 146);
			this.lblUsuario2.Name = "lblUsuario2";
			this.lblUsuario2.Size = new System.Drawing.Size(118, 31);
			this.lblUsuario2.TabIndex = 5;
			this.lblUsuario2.Text = "Usuário:";
			this.lblUsuario2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblSenha2
			// 
			this.lblSenha2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblSenha2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSenha2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblSenha2.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblSenha2.Location = new System.Drawing.Point(189, 244);
			this.lblSenha2.Name = "lblSenha2";
			this.lblSenha2.Size = new System.Drawing.Size(118, 31);
			this.lblSenha2.TabIndex = 6;
			this.lblSenha2.Text = "Senha:";
			this.lblSenha2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtUsuario2
			// 
			this.txtUsuario2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(217)))));
			this.txtUsuario2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtUsuario2.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtUsuario2.Location = new System.Drawing.Point(189, 195);
			this.txtUsuario2.Name = "txtUsuario2";
			this.txtUsuario2.Size = new System.Drawing.Size(791, 33);
			this.txtUsuario2.TabIndex = 8;
			// 
			// txtSenha2
			// 
			this.txtSenha2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(236)))), ((int)(((byte)(217)))));
			this.txtSenha2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtSenha2.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtSenha2.Location = new System.Drawing.Point(189, 287);
			this.txtSenha2.Name = "txtSenha2";
			this.txtSenha2.PasswordChar = '*';
			this.txtSenha2.Size = new System.Drawing.Size(791, 33);
			this.txtSenha2.TabIndex = 9;
			// 
			// btnCadastrar
			// 
			this.btnCadastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.btnCadastrar.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCadastrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnCadastrar.Location = new System.Drawing.Point(834, 340);
			this.btnCadastrar.Name = "btnCadastrar";
			this.btnCadastrar.Size = new System.Drawing.Size(120, 44);
			this.btnCadastrar.TabIndex = 11;
			this.btnCadastrar.Text = "Cadastrar";
			this.btnCadastrar.UseVisualStyleBackColor = false;
			this.btnCadastrar.Click += new System.EventHandler(this.BtnCadastrarClick);
			// 
			// lblComconta
			// 
			this.lblComconta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblComconta.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblComconta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblComconta.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblComconta.Location = new System.Drawing.Point(189, 346);
			this.lblComconta.Name = "lblComconta";
			this.lblComconta.Size = new System.Drawing.Size(238, 31);
			this.lblComconta.TabIndex = 12;
			this.lblComconta.Text = "Já possui uma conta?";
			this.lblComconta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblLogin2
			// 
			this.lblLogin2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblLogin2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lblLogin2.Font = new System.Drawing.Font("Arial", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLogin2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblLogin2.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblLogin2.Location = new System.Drawing.Point(401, 346);
			this.lblLogin2.Name = "lblLogin2";
			this.lblLogin2.Size = new System.Drawing.Size(199, 31);
			this.lblLogin2.TabIndex = 13;
			this.lblLogin2.Text = "Fazer login";
			this.lblLogin2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblLogin2.Click += new System.EventHandler(this.LblCrieumaClick);
			// 
			// Cadastro
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(1145, 470);
			this.Controls.Add(this.lblLogin2);
			this.Controls.Add(this.lblComconta);
			this.Controls.Add(this.btnCadastrar);
			this.Controls.Add(this.txtSenha2);
			this.Controls.Add(this.txtUsuario2);
			this.Controls.Add(this.lblSenha2);
			this.Controls.Add(this.lblUsuario2);
			this.Controls.Add(this.lblCadastro);
			this.Controls.Add(this.pictureBox1);
			this.Name = "Cadastro";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "+Habit";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label lblLogin2;
		private System.Windows.Forms.Label lblComconta;
		private System.Windows.Forms.Button btnCadastrar;
		private System.Windows.Forms.TextBox txtSenha2;
		private System.Windows.Forms.TextBox txtUsuario2;
		private System.Windows.Forms.Label lblSenha2;
		private System.Windows.Forms.Label lblUsuario2;
		private System.Windows.Forms.Label lblCadastro;
		private System.Windows.Forms.PictureBox pictureBox1;
	}
}
