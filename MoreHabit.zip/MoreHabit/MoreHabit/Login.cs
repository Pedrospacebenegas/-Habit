﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 17/11/2025
 * Time: 10:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace MoreHabit
{
	/// <summary>
	/// Description of Login.
	/// </summary>
	public partial class Login : Form
	{
		public Login()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		string arquivo = "usuarios.txt";
		
		void LblLoginClick(object sender, EventArgs e)
		{
			
		}
		
		void LblCrieumaClick(object sender, EventArgs e)
		{
			Cadastro telaCadastro = new Cadastro();
            telaCadastro.Show();
			this.Hide();			
		}
		
		void BtnEntrarClick(object sender, EventArgs e)
		{
 {
      string usuario = txtUsuario.Text.Trim();
      string senha = txtSenha.Text.Trim();

      if (!File.Exists(arquivo)){
        MessageBox.Show("Nenhum usuário cadastrado.");
      }

      bool encontrado = false;
      foreach (string linha in File.ReadAllLines(arquivo)){
        string[] dados = linha.Split(';');
        if (dados[0] == usuario && dados[1] == senha){
          MessageBox.Show("Login realizado com sucesso");
          encontrado = true;
          Inicio telaInicial = new Inicio();
          telaInicial.Show();
          this.Hide();
        }
      }

      if (encontrado == false){
        MessageBox.Show("Usuário ou senha incorretos.");
        txtUsuario.Clear();
        txtSenha.Clear();
      }
    }
  }
}			
		}
	

