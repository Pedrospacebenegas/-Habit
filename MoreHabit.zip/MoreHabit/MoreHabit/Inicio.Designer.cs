﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 18/11/2025
 * Time: 07:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace MoreHabit
{
	partial class Inicio
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lblQuiz = new System.Windows.Forms.Label();
			this.pctProva = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pctHabit = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pctProva)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pctHabit)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(134, 47);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(883, 398);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 4;
			this.pictureBox1.TabStop = false;
			// 
			// lblQuiz
			// 
			this.lblQuiz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.lblQuiz.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuiz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuiz.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.lblQuiz.Location = new System.Drawing.Point(207, 130);
			this.lblQuiz.Name = "lblQuiz";
			this.lblQuiz.Size = new System.Drawing.Size(341, 46);
			this.lblQuiz.TabIndex = 5;
			this.lblQuiz.Text = "Quiz Provão Paulista";
			this.lblQuiz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pctProva
			// 
			this.pctProva.Image = ((System.Drawing.Image)(resources.GetObject("pctProva.Image")));
			this.pctProva.Location = new System.Drawing.Point(283, 179);
			this.pctProva.Name = "pctProva";
			this.pctProva.Size = new System.Drawing.Size(158, 182);
			this.pctProva.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pctProva.TabIndex = 6;
			this.pctProva.TabStop = false;
			this.pctProva.Click += new System.EventHandler(this.PctProvaClick);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.label1.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.label1.Location = new System.Drawing.Point(596, 130);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(341, 46);
			this.label1.TabIndex = 7;
			this.label1.Text = "Quiz de Hábitos";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pctHabit
			// 
			this.pctHabit.Image = ((System.Drawing.Image)(resources.GetObject("pctHabit.Image")));
			this.pctHabit.Location = new System.Drawing.Point(684, 179);
			this.pctHabit.Name = "pctHabit";
			this.pctHabit.Size = new System.Drawing.Size(158, 182);
			this.pctHabit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pctHabit.TabIndex = 8;
			this.pctHabit.TabStop = false;
			this.pctHabit.Click += new System.EventHandler(this.PctHabitClick);
			// 
			// Inicio
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(1127, 512);
			this.Controls.Add(this.pctHabit);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pctProva);
			this.Controls.Add(this.lblQuiz);
			this.Controls.Add(this.pictureBox1);
			this.Name = "Inicio";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "+Habit";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pctProva)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pctHabit)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.PictureBox pctHabit;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pctProva;
		private System.Windows.Forms.Label lblQuiz;
		private System.Windows.Forms.PictureBox pictureBox1;
	}
}
