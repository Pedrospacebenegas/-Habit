﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 24/11/2025
 * Time: 09:23
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace MoreHabit
{
	partial class Provao
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Provao));
			this.btnVoltar2 = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pnlQuestao1 = new System.Windows.Forms.Panel();
			this.btnAlternativaD = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA = new System.Windows.Forms.RadioButton();
			this.lblQuestão1 = new System.Windows.Forms.Label();
			this.pctVidente = new System.Windows.Forms.PictureBox();
			this.pnlQuestao2 = new System.Windows.Forms.Panel();
			this.btnAlternativaD2 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC2 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB2 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA2 = new System.Windows.Forms.RadioButton();
			this.lblQuestao2 = new System.Windows.Forms.Label();
			this.pct = new System.Windows.Forms.PictureBox();
			this.pnlQuestao3 = new System.Windows.Forms.Panel();
			this.btnAlternativaD3 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC3 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB3 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA3 = new System.Windows.Forms.RadioButton();
			this.lblQuestao3 = new System.Windows.Forms.Label();
			this.pctEstufa = new System.Windows.Forms.PictureBox();
			this.btnAnterior = new System.Windows.Forms.Button();
			this.btnProximo = new System.Windows.Forms.Button();
			this.pnlQuestao4 = new System.Windows.Forms.Panel();
			this.btnAlternativaD4 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC4 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB4 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA4 = new System.Windows.Forms.RadioButton();
			this.lblQuestao4 = new System.Windows.Forms.Label();
			this.pctCaminhao = new System.Windows.Forms.PictureBox();
			this.pnlQuestao7 = new System.Windows.Forms.Panel();
			this.btnAlternativaD7 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC7 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB7 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA7 = new System.Windows.Forms.RadioButton();
			this.lblQuestao7 = new System.Windows.Forms.Label();
			this.pnlQuestao8 = new System.Windows.Forms.Panel();
			this.btnAlternativaD8 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC8 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB8 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA8 = new System.Windows.Forms.RadioButton();
			this.lblQuestao8 = new System.Windows.Forms.Label();
			this.pnlQuestao5 = new System.Windows.Forms.Panel();
			this.btnAlternativaD5 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC5 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB5 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA5 = new System.Windows.Forms.RadioButton();
			this.lblQuestao5 = new System.Windows.Forms.Label();
			this.pnlQuestao6 = new System.Windows.Forms.Panel();
			this.btnAlternativaD6 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaC6 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaB6 = new System.Windows.Forms.RadioButton();
			this.btnAlternativaA6 = new System.Windows.Forms.RadioButton();
			this.lblQuestao6 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.pnlQuestao1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pctVidente)).BeginInit();
			this.pnlQuestao2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pct)).BeginInit();
			this.pnlQuestao3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pctEstufa)).BeginInit();
			this.pnlQuestao4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pctCaminhao)).BeginInit();
			this.pnlQuestao7.SuspendLayout();
			this.pnlQuestao8.SuspendLayout();
			this.pnlQuestao5.SuspendLayout();
			this.pnlQuestao6.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnVoltar2
			// 
			this.btnVoltar2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.btnVoltar2.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnVoltar2.Location = new System.Drawing.Point(12, 12);
			this.btnVoltar2.Name = "btnVoltar2";
			this.btnVoltar2.Size = new System.Drawing.Size(120, 44);
			this.btnVoltar2.TabIndex = 13;
			this.btnVoltar2.Text = "Voltar";
			this.btnVoltar2.UseVisualStyleBackColor = false;
			this.btnVoltar2.Click += new System.EventHandler(this.BtnVoltarClick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(138, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(738, 335);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 14;
			this.pictureBox1.TabStop = false;
			// 
			// pnlQuestao1
			// 
			this.pnlQuestao1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao1.Controls.Add(this.btnAlternativaD);
			this.pnlQuestao1.Controls.Add(this.btnAlternativaC);
			this.pnlQuestao1.Controls.Add(this.btnAlternativaB);
			this.pnlQuestao1.Controls.Add(this.btnAlternativaA);
			this.pnlQuestao1.Controls.Add(this.lblQuestão1);
			this.pnlQuestao1.Controls.Add(this.pctVidente);
			this.pnlQuestao1.Location = new System.Drawing.Point(167, 43);
			this.pnlQuestao1.Name = "pnlQuestao1";
			this.pnlQuestao1.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao1.TabIndex = 17;
			// 
			// btnAlternativaD
			// 
			this.btnAlternativaD.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD.Location = new System.Drawing.Point(247, 209);
			this.btnAlternativaD.Name = "btnAlternativaD";
			this.btnAlternativaD.Size = new System.Drawing.Size(406, 39);
			this.btnAlternativaD.TabIndex = 5;
			this.btnAlternativaD.TabStop = true;
			this.btnAlternativaD.Text = "D) A pergunta feita pela atendente.";
			this.btnAlternativaD.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC
			// 
			this.btnAlternativaC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC.Location = new System.Drawing.Point(247, 168);
			this.btnAlternativaC.Name = "btnAlternativaC";
			this.btnAlternativaC.Size = new System.Drawing.Size(397, 35);
			this.btnAlternativaC.TabIndex = 4;
			this.btnAlternativaC.TabStop = true;
			this.btnAlternativaC.Text = "C) A falta de uma data de consulta.";
			this.btnAlternativaC.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB
			// 
			this.btnAlternativaB.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB.Location = new System.Drawing.Point(247, 108);
			this.btnAlternativaB.Name = "btnAlternativaB";
			this.btnAlternativaB.Size = new System.Drawing.Size(386, 54);
			this.btnAlternativaB.TabIndex = 3;
			this.btnAlternativaB.TabStop = true;
			this.btnAlternativaB.Text = "B) A confusão da idosa sobre o que é uma vidente.";
			this.btnAlternativaB.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA
			// 
			this.btnAlternativaA.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA.Location = new System.Drawing.Point(247, 51);
			this.btnAlternativaA.Name = "btnAlternativaA";
			this.btnAlternativaA.Size = new System.Drawing.Size(421, 55);
			this.btnAlternativaA.TabIndex = 2;
			this.btnAlternativaA.TabStop = true;
			this.btnAlternativaA.Text = "A) O fato da senhora ter que avisar a chegada para uma vidente.";
			this.btnAlternativaA.UseVisualStyleBackColor = true;
			// 
			// lblQuestão1
			// 
			this.lblQuestão1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestão1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestão1.Location = new System.Drawing.Point(231, 24);
			this.lblQuestão1.Name = "lblQuestão1";
			this.lblQuestão1.Size = new System.Drawing.Size(402, 33);
			this.lblQuestão1.TabIndex = 1;
			this.lblQuestão1.Text = "1. Qual a ironia desta tirinha?";
			// 
			// pctVidente
			// 
			this.pctVidente.Image = ((System.Drawing.Image)(resources.GetObject("pctVidente.Image")));
			this.pctVidente.Location = new System.Drawing.Point(30, 24);
			this.pctVidente.Name = "pctVidente";
			this.pctVidente.Size = new System.Drawing.Size(195, 224);
			this.pctVidente.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pctVidente.TabIndex = 0;
			this.pctVidente.TabStop = false;
			// 
			// pnlQuestao2
			// 
			this.pnlQuestao2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao2.Controls.Add(this.btnAlternativaD2);
			this.pnlQuestao2.Controls.Add(this.btnAlternativaC2);
			this.pnlQuestao2.Controls.Add(this.btnAlternativaB2);
			this.pnlQuestao2.Controls.Add(this.btnAlternativaA2);
			this.pnlQuestao2.Controls.Add(this.lblQuestao2);
			this.pnlQuestao2.Controls.Add(this.pct);
			this.pnlQuestao2.Location = new System.Drawing.Point(161, 46);
			this.pnlQuestao2.Name = "pnlQuestao2";
			this.pnlQuestao2.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao2.TabIndex = 18;
			this.pnlQuestao2.Visible = false;
			// 
			// btnAlternativaD2
			// 
			this.btnAlternativaD2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD2.Location = new System.Drawing.Point(209, 194);
			this.btnAlternativaD2.Name = "btnAlternativaD2";
			this.btnAlternativaD2.Size = new System.Drawing.Size(406, 39);
			this.btnAlternativaD2.TabIndex = 5;
			this.btnAlternativaD2.TabStop = true;
			this.btnAlternativaD2.Text = "D) Fazer dieta.";
			this.btnAlternativaD2.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC2
			// 
			this.btnAlternativaC2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC2.Location = new System.Drawing.Point(209, 153);
			this.btnAlternativaC2.Name = "btnAlternativaC2";
			this.btnAlternativaC2.Size = new System.Drawing.Size(397, 35);
			this.btnAlternativaC2.TabIndex = 4;
			this.btnAlternativaC2.TabStop = true;
			this.btnAlternativaC2.Text = "C) Se revoltar.";
			this.btnAlternativaC2.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB2
			// 
			this.btnAlternativaB2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB2.Location = new System.Drawing.Point(209, 93);
			this.btnAlternativaB2.Name = "btnAlternativaB2";
			this.btnAlternativaB2.Size = new System.Drawing.Size(386, 54);
			this.btnAlternativaB2.TabIndex = 3;
			this.btnAlternativaB2.TabStop = true;
			this.btnAlternativaB2.Text = "B) Adormecer.";
			this.btnAlternativaB2.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA2
			// 
			this.btnAlternativaA2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA2.Location = new System.Drawing.Point(209, 47);
			this.btnAlternativaA2.Name = "btnAlternativaA2";
			this.btnAlternativaA2.Size = new System.Drawing.Size(421, 55);
			this.btnAlternativaA2.TabIndex = 2;
			this.btnAlternativaA2.TabStop = true;
			this.btnAlternativaA2.Text = "A) Começar a se exercitar.";
			this.btnAlternativaA2.UseVisualStyleBackColor = true;
			// 
			// lblQuestao2
			// 
			this.lblQuestao2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao2.Location = new System.Drawing.Point(193, 0);
			this.lblQuestao2.Name = "lblQuestao2";
			this.lblQuestao2.Size = new System.Drawing.Size(488, 57);
			this.lblQuestao2.TabIndex = 1;
			this.lblQuestao2.Text = "2. Nesta tirinha, Garfield se contradiz, pode ser usado como prova o fato dele:";
			// 
			// pct
			// 
			this.pct.Image = ((System.Drawing.Image)(resources.GetObject("pct.Image")));
			this.pct.Location = new System.Drawing.Point(70, 0);
			this.pct.Name = "pct";
			this.pct.Size = new System.Drawing.Size(117, 259);
			this.pct.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pct.TabIndex = 0;
			this.pct.TabStop = false;
			// 
			// pnlQuestao3
			// 
			this.pnlQuestao3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao3.Controls.Add(this.btnAlternativaD3);
			this.pnlQuestao3.Controls.Add(this.btnAlternativaC3);
			this.pnlQuestao3.Controls.Add(this.btnAlternativaB3);
			this.pnlQuestao3.Controls.Add(this.btnAlternativaA3);
			this.pnlQuestao3.Controls.Add(this.lblQuestao3);
			this.pnlQuestao3.Controls.Add(this.pctEstufa);
			this.pnlQuestao3.Location = new System.Drawing.Point(173, 33);
			this.pnlQuestao3.Name = "pnlQuestao3";
			this.pnlQuestao3.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao3.TabIndex = 19;
			this.pnlQuestao3.Visible = false;
			// 
			// btnAlternativaD3
			// 
			this.btnAlternativaD3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD3.Location = new System.Drawing.Point(410, 164);
			this.btnAlternativaD3.Name = "btnAlternativaD3";
			this.btnAlternativaD3.Size = new System.Drawing.Size(199, 39);
			this.btnAlternativaD3.TabIndex = 5;
			this.btnAlternativaD3.TabStop = true;
			this.btnAlternativaD3.Text = "D) Ondas de calor.";
			this.btnAlternativaD3.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC3
			// 
			this.btnAlternativaC3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC3.Location = new System.Drawing.Point(221, 153);
			this.btnAlternativaC3.Name = "btnAlternativaC3";
			this.btnAlternativaC3.Size = new System.Drawing.Size(201, 49);
			this.btnAlternativaC3.TabIndex = 4;
			this.btnAlternativaC3.TabStop = true;
			this.btnAlternativaC3.Text = "C) Abalo sismicos.";
			this.btnAlternativaC3.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB3
			// 
			this.btnAlternativaB3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB3.Location = new System.Drawing.Point(419, 107);
			this.btnAlternativaB3.Name = "btnAlternativaB3";
			this.btnAlternativaB3.Size = new System.Drawing.Size(223, 54);
			this.btnAlternativaB3.TabIndex = 3;
			this.btnAlternativaB3.TabStop = true;
			this.btnAlternativaB3.Text = "B) Erosão.";
			this.btnAlternativaB3.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA3
			// 
			this.btnAlternativaA3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA3.Location = new System.Drawing.Point(221, 107);
			this.btnAlternativaA3.Name = "btnAlternativaA3";
			this.btnAlternativaA3.Size = new System.Drawing.Size(421, 55);
			this.btnAlternativaA3.TabIndex = 2;
			this.btnAlternativaA3.TabStop = true;
			this.btnAlternativaA3.Text = "A) Efeito estufa.";
			this.btnAlternativaA3.UseVisualStyleBackColor = true;
			// 
			// lblQuestao3
			// 
			this.lblQuestao3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao3.Location = new System.Drawing.Point(221, 0);
			this.lblQuestao3.Name = "lblQuestao3";
			this.lblQuestao3.Size = new System.Drawing.Size(447, 90);
			this.lblQuestao3.TabIndex = 1;
			this.lblQuestao3.Text = "3. O Gráfico a seguir mostra um efeito que causa o aquecimento global, esse efeit" +
			"o é maior em áreas metropolitanas. Qual o nome deste fenômeno natural?";
			// 
			// pctEstufa
			// 
			this.pctEstufa.Image = ((System.Drawing.Image)(resources.GetObject("pctEstufa.Image")));
			this.pctEstufa.Location = new System.Drawing.Point(16, 0);
			this.pctEstufa.Name = "pctEstufa";
			this.pctEstufa.Size = new System.Drawing.Size(199, 259);
			this.pctEstufa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pctEstufa.TabIndex = 0;
			this.pctEstufa.TabStop = false;
			// 
			// btnAnterior
			// 
			this.btnAnterior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.btnAnterior.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAnterior.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAnterior.Location = new System.Drawing.Point(138, 353);
			this.btnAnterior.Name = "btnAnterior";
			this.btnAnterior.Size = new System.Drawing.Size(120, 44);
			this.btnAnterior.TabIndex = 18;
			this.btnAnterior.Text = "Anterior";
			this.btnAnterior.UseVisualStyleBackColor = false;
			this.btnAnterior.Click += new System.EventHandler(this.BtnAnteriorClick);
			// 
			// btnProximo
			// 
			this.btnProximo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.btnProximo.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnProximo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnProximo.Location = new System.Drawing.Point(756, 353);
			this.btnProximo.Name = "btnProximo";
			this.btnProximo.Size = new System.Drawing.Size(120, 44);
			this.btnProximo.TabIndex = 19;
			this.btnProximo.Text = "Próximo";
			this.btnProximo.UseVisualStyleBackColor = false;
			this.btnProximo.Click += new System.EventHandler(this.BtnProximoClick);
			// 
			// pnlQuestao4
			// 
			this.pnlQuestao4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao4.Controls.Add(this.btnAlternativaD4);
			this.pnlQuestao4.Controls.Add(this.btnAlternativaC4);
			this.pnlQuestao4.Controls.Add(this.btnAlternativaB4);
			this.pnlQuestao4.Controls.Add(this.btnAlternativaA4);
			this.pnlQuestao4.Controls.Add(this.lblQuestao4);
			this.pnlQuestao4.Controls.Add(this.pctCaminhao);
			this.pnlQuestao4.Location = new System.Drawing.Point(170, 39);
			this.pnlQuestao4.Name = "pnlQuestao4";
			this.pnlQuestao4.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao4.TabIndex = 20;
			this.pnlQuestao4.Visible = false;
			// 
			// btnAlternativaD4
			// 
			this.btnAlternativaD4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD4.Location = new System.Drawing.Point(221, 208);
			this.btnAlternativaD4.Name = "btnAlternativaD4";
			this.btnAlternativaD4.Size = new System.Drawing.Size(362, 39);
			this.btnAlternativaD4.TabIndex = 5;
			this.btnAlternativaD4.TabStop = true;
			this.btnAlternativaD4.Text = "D) Caminhão 1, pela lei da inercia.";
			this.btnAlternativaD4.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC4
			// 
			this.btnAlternativaC4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC4.Location = new System.Drawing.Point(221, 153);
			this.btnAlternativaC4.Name = "btnAlternativaC4";
			this.btnAlternativaC4.Size = new System.Drawing.Size(447, 49);
			this.btnAlternativaC4.TabIndex = 4;
			this.btnAlternativaC4.TabStop = true;
			this.btnAlternativaC4.Text = "C) Caminhão 3, Pela Principio fundamental da dinâmica.";
			this.btnAlternativaC4.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB4
			// 
			this.btnAlternativaB4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB4.Location = new System.Drawing.Point(221, 104);
			this.btnAlternativaB4.Name = "btnAlternativaB4";
			this.btnAlternativaB4.Size = new System.Drawing.Size(377, 54);
			this.btnAlternativaB4.TabIndex = 3;
			this.btnAlternativaB4.TabStop = true;
			this.btnAlternativaB4.Text = "B) Caminhão 2, Pela lei da inercia.";
			this.btnAlternativaB4.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA4
			// 
			this.btnAlternativaA4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA4.Location = new System.Drawing.Point(221, 54);
			this.btnAlternativaA4.Name = "btnAlternativaA4";
			this.btnAlternativaA4.Size = new System.Drawing.Size(421, 55);
			this.btnAlternativaA4.TabIndex = 2;
			this.btnAlternativaA4.TabStop = true;
			this.btnAlternativaA4.Text = "A) Caminhão 2, isso se dá pela Lei de ação e reação.";
			this.btnAlternativaA4.UseVisualStyleBackColor = true;
			// 
			// lblQuestao4
			// 
			this.lblQuestao4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao4.Location = new System.Drawing.Point(221, 27);
			this.lblQuestao4.Name = "lblQuestao4";
			this.lblQuestao4.Size = new System.Drawing.Size(447, 33);
			this.lblQuestao4.TabIndex = 1;
			this.lblQuestao4.Text = "4. Qual dos três caminhões está freando:";
			// 
			// pctCaminhao
			// 
			this.pctCaminhao.Image = ((System.Drawing.Image)(resources.GetObject("pctCaminhao.Image")));
			this.pctCaminhao.Location = new System.Drawing.Point(16, 0);
			this.pctCaminhao.Name = "pctCaminhao";
			this.pctCaminhao.Size = new System.Drawing.Size(199, 268);
			this.pctCaminhao.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pctCaminhao.TabIndex = 0;
			this.pctCaminhao.TabStop = false;
			// 
			// pnlQuestao7
			// 
			this.pnlQuestao7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao7.Controls.Add(this.btnAlternativaD7);
			this.pnlQuestao7.Controls.Add(this.btnAlternativaC7);
			this.pnlQuestao7.Controls.Add(this.btnAlternativaB7);
			this.pnlQuestao7.Controls.Add(this.btnAlternativaA7);
			this.pnlQuestao7.Controls.Add(this.lblQuestao7);
			this.pnlQuestao7.Location = new System.Drawing.Point(164, 40);
			this.pnlQuestao7.Name = "pnlQuestao7";
			this.pnlQuestao7.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao7.TabIndex = 21;
			this.pnlQuestao7.Visible = false;
			// 
			// btnAlternativaD7
			// 
			this.btnAlternativaD7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD7.Location = new System.Drawing.Point(19, 195);
			this.btnAlternativaD7.Name = "btnAlternativaD7";
			this.btnAlternativaD7.Size = new System.Drawing.Size(662, 70);
			this.btnAlternativaD7.TabIndex = 5;
			this.btnAlternativaD7.TabStop = true;
			this.btnAlternativaD7.Text = "D) Um morador de Taboão da serra indo para São Paulo.";
			this.btnAlternativaD7.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC7
			// 
			this.btnAlternativaC7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC7.Location = new System.Drawing.Point(18, 161);
			this.btnAlternativaC7.Name = "btnAlternativaC7";
			this.btnAlternativaC7.Size = new System.Drawing.Size(618, 49);
			this.btnAlternativaC7.TabIndex = 4;
			this.btnAlternativaC7.TabStop = true;
			this.btnAlternativaC7.Text = "C) Um morador de Xique-Xique se mudando para o Amazonas.";
			this.btnAlternativaC7.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB7
			// 
			this.btnAlternativaB7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB7.Location = new System.Drawing.Point(19, 110);
			this.btnAlternativaB7.Name = "btnAlternativaB7";
			this.btnAlternativaB7.Size = new System.Drawing.Size(644, 48);
			this.btnAlternativaB7.TabIndex = 3;
			this.btnAlternativaB7.TabStop = true;
			this.btnAlternativaB7.Text = "B) Um morador da França indo para a Alemanha.";
			this.btnAlternativaB7.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA7
			// 
			this.btnAlternativaA7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA7.Location = new System.Drawing.Point(19, 51);
			this.btnAlternativaA7.Name = "btnAlternativaA7";
			this.btnAlternativaA7.Size = new System.Drawing.Size(665, 69);
			this.btnAlternativaA7.TabIndex = 2;
			this.btnAlternativaA7.TabStop = true;
			this.btnAlternativaA7.Text = "A) Um morador do maranhão indo para São Paulo.";
			this.btnAlternativaA7.UseVisualStyleBackColor = true;
			// 
			// lblQuestao7
			// 
			this.lblQuestao7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao7.Location = new System.Drawing.Point(3, 6);
			this.lblQuestao7.Name = "lblQuestao7";
			this.lblQuestao7.Size = new System.Drawing.Size(648, 60);
			this.lblQuestao7.TabIndex = 1;
			this.lblQuestao7.Text = "7. A imigração é o ato de sair de seu país para outro em busca de uma qualidade d" +
			"e vida melhor, pode ser considerado um exemplo disso:";
			this.lblQuestao7.Click += new System.EventHandler(this.Label1Click);
			// 
			// pnlQuestao8
			// 
			this.pnlQuestao8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao8.Controls.Add(this.btnAlternativaD8);
			this.pnlQuestao8.Controls.Add(this.btnAlternativaC8);
			this.pnlQuestao8.Controls.Add(this.btnAlternativaB8);
			this.pnlQuestao8.Controls.Add(this.btnAlternativaA8);
			this.pnlQuestao8.Controls.Add(this.lblQuestao8);
			this.pnlQuestao8.Location = new System.Drawing.Point(161, 48);
			this.pnlQuestao8.Name = "pnlQuestao8";
			this.pnlQuestao8.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao8.TabIndex = 22;
			this.pnlQuestao8.Visible = false;
			// 
			// btnAlternativaD8
			// 
			this.btnAlternativaD8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD8.Location = new System.Drawing.Point(351, 160);
			this.btnAlternativaD8.Name = "btnAlternativaD8";
			this.btnAlternativaD8.Size = new System.Drawing.Size(662, 70);
			this.btnAlternativaD8.TabIndex = 5;
			this.btnAlternativaD8.TabStop = true;
			this.btnAlternativaD8.Text = "D) Italiano.";
			this.btnAlternativaD8.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC8
			// 
			this.btnAlternativaC8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC8.Location = new System.Drawing.Point(15, 165);
			this.btnAlternativaC8.Name = "btnAlternativaC8";
			this.btnAlternativaC8.Size = new System.Drawing.Size(618, 49);
			this.btnAlternativaC8.TabIndex = 4;
			this.btnAlternativaC8.TabStop = true;
			this.btnAlternativaC8.Text = "C) Espanhol.";
			this.btnAlternativaC8.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB8
			// 
			this.btnAlternativaB8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB8.Location = new System.Drawing.Point(351, 123);
			this.btnAlternativaB8.Name = "btnAlternativaB8";
			this.btnAlternativaB8.Size = new System.Drawing.Size(644, 48);
			this.btnAlternativaB8.TabIndex = 3;
			this.btnAlternativaB8.TabStop = true;
			this.btnAlternativaB8.Text = "B) Português.";
			this.btnAlternativaB8.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA8
			// 
			this.btnAlternativaA8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA8.Location = new System.Drawing.Point(18, 110);
			this.btnAlternativaA8.Name = "btnAlternativaA8";
			this.btnAlternativaA8.Size = new System.Drawing.Size(665, 69);
			this.btnAlternativaA8.TabIndex = 2;
			this.btnAlternativaA8.TabStop = true;
			this.btnAlternativaA8.Text = "A) Inglês.";
			this.btnAlternativaA8.UseVisualStyleBackColor = true;
			// 
			// lblQuestao8
			// 
			this.lblQuestao8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao8.Location = new System.Drawing.Point(3, 6);
			this.lblQuestao8.Name = "lblQuestao8";
			this.lblQuestao8.Size = new System.Drawing.Size(648, 114);
			this.lblQuestao8.TabIndex = 1;
			this.lblQuestao8.Text = resources.GetString("lblQuestao8.Text");
			// 
			// pnlQuestao5
			// 
			this.pnlQuestao5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao5.Controls.Add(this.btnAlternativaD5);
			this.pnlQuestao5.Controls.Add(this.btnAlternativaC5);
			this.pnlQuestao5.Controls.Add(this.btnAlternativaB5);
			this.pnlQuestao5.Controls.Add(this.btnAlternativaA5);
			this.pnlQuestao5.Controls.Add(this.lblQuestao5);
			this.pnlQuestao5.Location = new System.Drawing.Point(167, 40);
			this.pnlQuestao5.Name = "pnlQuestao5";
			this.pnlQuestao5.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao5.TabIndex = 22;
			this.pnlQuestao5.Visible = false;
			// 
			// btnAlternativaD5
			// 
			this.btnAlternativaD5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD5.Location = new System.Drawing.Point(403, 208);
			this.btnAlternativaD5.Name = "btnAlternativaD5";
			this.btnAlternativaD5.Size = new System.Drawing.Size(362, 39);
			this.btnAlternativaD5.TabIndex = 5;
			this.btnAlternativaD5.TabStop = true;
			this.btnAlternativaD5.Text = "D) 6";
			this.btnAlternativaD5.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC5
			// 
			this.btnAlternativaC5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC5.Location = new System.Drawing.Point(48, 205);
			this.btnAlternativaC5.Name = "btnAlternativaC5";
			this.btnAlternativaC5.Size = new System.Drawing.Size(447, 49);
			this.btnAlternativaC5.TabIndex = 4;
			this.btnAlternativaC5.TabStop = true;
			this.btnAlternativaC5.Text = "C) 5";
			this.btnAlternativaC5.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB5
			// 
			this.btnAlternativaB5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB5.Location = new System.Drawing.Point(403, 140);
			this.btnAlternativaB5.Name = "btnAlternativaB5";
			this.btnAlternativaB5.Size = new System.Drawing.Size(230, 54);
			this.btnAlternativaB5.TabIndex = 3;
			this.btnAlternativaB5.TabStop = true;
			this.btnAlternativaB5.Text = "B) 4";
			this.btnAlternativaB5.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA5
			// 
			this.btnAlternativaA5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA5.Location = new System.Drawing.Point(48, 139);
			this.btnAlternativaA5.Name = "btnAlternativaA5";
			this.btnAlternativaA5.Size = new System.Drawing.Size(421, 55);
			this.btnAlternativaA5.TabIndex = 2;
			this.btnAlternativaA5.TabStop = true;
			this.btnAlternativaA5.Text = "A) 2";
			this.btnAlternativaA5.UseVisualStyleBackColor = true;
			// 
			// lblQuestao5
			// 
			this.lblQuestao5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao5.Location = new System.Drawing.Point(9, 0);
			this.lblQuestao5.Name = "lblQuestao5";
			this.lblQuestao5.Size = new System.Drawing.Size(684, 137);
			this.lblQuestao5.TabIndex = 1;
			this.lblQuestao5.Text = resources.GetString("lblQuestao5.Text");
			// 
			// pnlQuestao6
			// 
			this.pnlQuestao6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(234)))));
			this.pnlQuestao6.Controls.Add(this.btnAlternativaD6);
			this.pnlQuestao6.Controls.Add(this.btnAlternativaC6);
			this.pnlQuestao6.Controls.Add(this.btnAlternativaB6);
			this.pnlQuestao6.Controls.Add(this.btnAlternativaA6);
			this.pnlQuestao6.Controls.Add(this.lblQuestao6);
			this.pnlQuestao6.Location = new System.Drawing.Point(164, 36);
			this.pnlQuestao6.Name = "pnlQuestao6";
			this.pnlQuestao6.Size = new System.Drawing.Size(687, 265);
			this.pnlQuestao6.TabIndex = 22;
			this.pnlQuestao6.Visible = false;
			// 
			// btnAlternativaD6
			// 
			this.btnAlternativaD6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaD6.Location = new System.Drawing.Point(19, 195);
			this.btnAlternativaD6.Name = "btnAlternativaD6";
			this.btnAlternativaD6.Size = new System.Drawing.Size(662, 70);
			this.btnAlternativaD6.TabIndex = 5;
			this.btnAlternativaD6.TabStop = true;
			this.btnAlternativaD6.Text = "D) Substitui a análise econômica e a pesquisa de mercado.";
			this.btnAlternativaD6.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaC6
			// 
			this.btnAlternativaC6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaC6.Location = new System.Drawing.Point(18, 161);
			this.btnAlternativaC6.Name = "btnAlternativaC6";
			this.btnAlternativaC6.Size = new System.Drawing.Size(618, 49);
			this.btnAlternativaC6.TabIndex = 4;
			this.btnAlternativaC6.TabStop = true;
			this.btnAlternativaC6.Text = "C) Fornece modelos matemáticos exatos para prever o mercado.";
			this.btnAlternativaC6.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaB6
			// 
			this.btnAlternativaB6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaB6.Location = new System.Drawing.Point(19, 110);
			this.btnAlternativaB6.Name = "btnAlternativaB6";
			this.btnAlternativaB6.Size = new System.Drawing.Size(644, 48);
			this.btnAlternativaB6.TabIndex = 3;
			this.btnAlternativaB6.TabStop = true;
			this.btnAlternativaB6.Text = "B) Ensina técnicas diretas de vendas e negociação.";
			this.btnAlternativaB6.UseVisualStyleBackColor = true;
			// 
			// btnAlternativaA6
			// 
			this.btnAlternativaA6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.btnAlternativaA6.Location = new System.Drawing.Point(19, 51);
			this.btnAlternativaA6.Name = "btnAlternativaA6";
			this.btnAlternativaA6.Size = new System.Drawing.Size(665, 69);
			this.btnAlternativaA6.TabIndex = 2;
			this.btnAlternativaA6.TabStop = true;
			this.btnAlternativaA6.Text = "A) Oferece reflexão crítica sobre valores, cultura, ética e mudanças sociais que " +
			"influenciam oportunidades.";
			this.btnAlternativaA6.UseVisualStyleBackColor = true;
			// 
			// lblQuestao6
			// 
			this.lblQuestao6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuestao6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(142)))), ((int)(((byte)(31)))));
			this.lblQuestao6.Location = new System.Drawing.Point(3, 6);
			this.lblQuestao6.Name = "lblQuestao6";
			this.lblQuestao6.Size = new System.Drawing.Size(624, 60);
			this.lblQuestao6.TabIndex = 1;
			this.lblQuestao6.Text = "6. Como a filosofia pode contribuir para a compreensão dos cenários contemporâneo" +
			"s de oportunidades empreendedoras?";
			// 
			// Provao
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.ClientSize = new System.Drawing.Size(994, 418);
			this.Controls.Add(this.pnlQuestao2);
			this.Controls.Add(this.pnlQuestao3);
			this.Controls.Add(this.pnlQuestao6);
			this.Controls.Add(this.pnlQuestao7);
			this.Controls.Add(this.pnlQuestao8);
			this.Controls.Add(this.pnlQuestao5);
			this.Controls.Add(this.pnlQuestao4);
			this.Controls.Add(this.btnProximo);
			this.Controls.Add(this.btnAnterior);
			this.Controls.Add(this.pnlQuestao1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.btnVoltar2);
			this.Name = "Provao";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "+Habit";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.pnlQuestao1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pctVidente)).EndInit();
			this.pnlQuestao2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pct)).EndInit();
			this.pnlQuestao3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pctEstufa)).EndInit();
			this.pnlQuestao4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pctCaminhao)).EndInit();
			this.pnlQuestao7.ResumeLayout(false);
			this.pnlQuestao8.ResumeLayout(false);
			this.pnlQuestao5.ResumeLayout(false);
			this.pnlQuestao6.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lblQuestao5;
		private System.Windows.Forms.RadioButton btnAlternativaA5;
		private System.Windows.Forms.RadioButton btnAlternativaB5;
		private System.Windows.Forms.RadioButton btnAlternativaC5;
		private System.Windows.Forms.RadioButton btnAlternativaD5;
		private System.Windows.Forms.Label lblQuestao6;
		private System.Windows.Forms.RadioButton btnAlternativaA6;
		private System.Windows.Forms.RadioButton btnAlternativaB6;
		private System.Windows.Forms.RadioButton btnAlternativaC6;
		private System.Windows.Forms.RadioButton btnAlternativaD6;
		private System.Windows.Forms.Panel pnlQuestao6;
		private System.Windows.Forms.Panel pnlQuestao5;
		private System.Windows.Forms.Label lblQuestao8;
		private System.Windows.Forms.RadioButton btnAlternativaA8;
		private System.Windows.Forms.RadioButton btnAlternativaB8;
		private System.Windows.Forms.RadioButton btnAlternativaC8;
		private System.Windows.Forms.RadioButton btnAlternativaD8;
		private System.Windows.Forms.Panel pnlQuestao8;
		private System.Windows.Forms.Label lblQuestao7;
		private System.Windows.Forms.RadioButton btnAlternativaA7;
		private System.Windows.Forms.RadioButton btnAlternativaB7;
		private System.Windows.Forms.RadioButton btnAlternativaC7;
		private System.Windows.Forms.RadioButton btnAlternativaD7;
		private System.Windows.Forms.Panel pnlQuestao7;
		private System.Windows.Forms.PictureBox pctCaminhao;
		private System.Windows.Forms.Label lblQuestao4;
		private System.Windows.Forms.RadioButton btnAlternativaA4;
		private System.Windows.Forms.RadioButton btnAlternativaB4;
		private System.Windows.Forms.RadioButton btnAlternativaC4;
		private System.Windows.Forms.RadioButton btnAlternativaD4;
		private System.Windows.Forms.Panel pnlQuestao4;
		private System.Windows.Forms.PictureBox pctEstufa;
		private System.Windows.Forms.Label lblQuestao3;
		private System.Windows.Forms.RadioButton btnAlternativaA3;
		private System.Windows.Forms.RadioButton btnAlternativaB3;
		private System.Windows.Forms.RadioButton btnAlternativaC3;
		private System.Windows.Forms.RadioButton btnAlternativaD3;
		private System.Windows.Forms.Panel pnlQuestao3;
		private System.Windows.Forms.PictureBox pct;
		private System.Windows.Forms.Label lblQuestao2;
		private System.Windows.Forms.RadioButton btnAlternativaA2;
		private System.Windows.Forms.RadioButton btnAlternativaB2;
		private System.Windows.Forms.RadioButton btnAlternativaC2;
		private System.Windows.Forms.RadioButton btnAlternativaD2;
		private System.Windows.Forms.Panel pnlQuestao2;
		private System.Windows.Forms.Button btnProximo;
		private System.Windows.Forms.Button btnAnterior;
		private System.Windows.Forms.PictureBox pctVidente;
		private System.Windows.Forms.Label lblQuestão1;
		private System.Windows.Forms.RadioButton btnAlternativaA;
		private System.Windows.Forms.RadioButton btnAlternativaB;
		private System.Windows.Forms.RadioButton btnAlternativaC;
		private System.Windows.Forms.RadioButton btnAlternativaD;
		private System.Windows.Forms.Panel pnlQuestao1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btnVoltar2;
	}
}
