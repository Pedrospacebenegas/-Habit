﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 17/11/2025
 * Time: 11:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace MoreHabit
{
	/// <summary>
	/// Description of Cadastro.
	/// </summary>
	public partial class Cadastro : Form
	{
		public Cadastro()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		string arquivo = "usuarios.txt";
		
		void LblCrieumaClick(object sender, EventArgs e)
		{
			 Login telaLogin = new Login();
            telaLogin.Show();
			this.Hide();
		}
		
    void BtnCadastrarClick(object sender, EventArgs e)
    {
      string usuario = txtUsuario2.Text.Trim();
      string senha = txtSenha2.Text.Trim();

      if (usuario == "" || senha == ""){
        MessageBox.Show("Preencha o usuário e a senha.");
      } else {
        bool cadastrado = false;
        if (File.Exists(arquivo)){
            foreach (string linha in File.ReadAllLines(arquivo)) {
              string[] dados = linha.Split(';');
              if (dados[0] == usuario){
                MessageBox.Show("Usuário já cadastrado.");
                cadastrado = true;
              }
            }
        }

        if (cadastrado == false){
          using (StreamWriter sw = File.AppendText(arquivo)){
            sw.WriteLine(usuario + ";" + senha);
            cadastrado = true;
          }
          MessageBox.Show("Cadastro realizado com sucesso!");
          Inicio telaInicial = new Inicio();
          telaInicial.Show();
          this.Hide();
          
        }          
      }

      txtUsuario2.Clear();
      txtSenha2.Clear();
    }
	}
}
	