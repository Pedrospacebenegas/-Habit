﻿/*
 * Created by SharpDevelop.
 * User: 20252930033
 * Date: 18/11/2025
 * Time: 07:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace MoreHabit
{
	/// <summary>
	/// Description of Inicio.
	/// </summary>
	public partial class Inicio : Form
	{
		public Inicio()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void PctProvaClick(object sender, EventArgs e)
		{
			Provao telaProvao = new Provao();
			telaProvao.Show();
			this.Hide();
		}
		
		void PctHabitClick(object sender, EventArgs e)
		{
			Habitos telaHabitos = new Habitos();
			telaHabitos.Show();
			this.Hide();
		}
	}
}
